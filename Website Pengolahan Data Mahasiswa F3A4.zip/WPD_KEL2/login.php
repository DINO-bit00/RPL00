<?php
session_start();
require_once "config/database.php";

$error = ''; // Awalnya tidak ada error

// Jika sudah login, arahkan ke index.php
if (isset($_SESSION['login'])) {
    header('location:index.php');
    exit;
}

// Proses login
if (isset($_POST['submit-login'])) {
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $password = md5($_POST['password']); // Gunakan md5, namun password_hash lebih disarankan untuk keamanan lebih baik

    // Query untuk memeriksa username dan password
    $result = mysqli_query($db, "SELECT * FROM admin WHERE username = '$username' AND password = '$password'");

    // Cek apakah hasil query ada
    if (mysqli_num_rows($result) > 0) {
        $_SESSION['login'] = true; // Set session login
        header('location:index.php'); // Arahkan ke halaman index
        exit;
    } else {
        $error = "Username atau password salah!"; // Set pesan error jika login gagal
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="shortcut icon" href="assets/img/Logo_ubhara.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="assets/css/login.css"> <!-- Link CSS Anda -->
</head>
<body>
    <div class="wrapper">
        <div class="form-wrapper login">
            <form action="" method="post">
                <h2>Login</h2>

                <!-- Tampilkan pesan error jika ada -->
                <?php if (!empty($error)): ?>
                    <div class="error-message"><?php echo $error; ?></div>
                <?php endif; ?>

                <div class="input-group">
                    <input type="text" name="username" required>
                    <label for="">Username</label>
                </div>
                <div class="input-group">
                    <input type="password" name="password" required>
                    <label for="">Password</label>
                </div>
                <input type="submit" name="submit-login" class="btn" value="Login">
            </form>
        </div>
    </div>
</body>
</html>
